
<?php
/*
Plugin Name: ThetaAIM AI Plugin
Description: A Theta EdgeCloud AI plugin that sends a request to an interference API and displays the response.
Version: 1.0
Author: ThetaAIM Team
*/

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

define('API_KEY', 'ziufdabljynvqgexaprbskowihnyl');

// Enqueue JavaScript
function taip_enqueue_scripts() {
    wp_enqueue_script('taip-script', plugins_url('taip-script.js', __FILE__), array('jquery'), '1.0', true);
    wp_localize_script('taip-script', 'taip_ajax_obj', array(
        'ajax_url' => admin_url('admin-ajax.php')
    ));
}
add_action('wp_enqueue_scripts', 'taip_enqueue_scripts');

// Add Shortcode
function taip_shortcode() {
    ob_start();
    ?>
    <form id="taip-form">
        <input type="text" id="taip-input" name="taip_input" placeholder="Enter something">
        <button type="submit">Submit</button>
    </form>
    <div id="taip-response"></div>
    <?php
    return ob_get_clean();
}
add_shortcode('taip_form', 'taip_shortcode');

// Handle AJAX Request
function taip_handle_ajax_request() {
    $input = sanitize_text_field($_POST['input']);

    // Replace with your external API URL
    $api_url = 'https://qtmkziufdabljynvqgexaprbskowihnylzdutcs.onthetaedgecloud.com?query=' . urlencode($input) . '&api_key=' . API_KEY;

    $response = wp_remote_get($api_url);

    if (is_wp_error($response)) {
        $error_message = $response->get_error_message();
        wp_send_json_error($error_message);
    } else {
        $body = wp_remote_retrieve_body($response);
        wp_send_json_success($body);
    }
}
add_action('wp_ajax_taip_handle_request', 'taip_handle_ajax_request');
add_action('wp_ajax_nopriv_taip_handle_request', 'taip_handle_ajax_request');
