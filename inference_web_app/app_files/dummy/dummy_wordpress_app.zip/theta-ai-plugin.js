
jQuery(document).ready(function($) {
    $('#taip-form').on('submit', function(event) {
        event.preventDefault();

        var input = $('#taip-input').val();

        $.ajax({
            url: taip_ajax_obj.ajax_url,
            type: 'post',
            data: {
                action: 'taip_handle_request',
                input: input
            },
            success: function(response) {
                if (response.success) {
                    $('#taip-response').html('<p>' + response.data + '</p>');
                } else {
                    $('#taip-response').html('<p>Error: ' + response.data + '</p>');
                }
            }
        });
    });
});
