
document.addEventListener('DOMContentLoaded', function () {
  const chatBox = document.getElementById('chat-box');
  const queryInput = document.getElementById('query');
  const sendBtn = document.getElementById('send-btn');

  const apiKey = 'ziufdabljynvqgexaprbskowihnyl';
  const apiEndpoint = 'https://qtmkziufdabljynvqgexaprbskowihnylzdutcs.onthetaedgecloud.com';

  sendBtn.addEventListener('click', function () {
    const query = queryInput.value;
    if (query) {
      sendMessage(query);
    }
  });

  function sendMessage(message) {
    displayMessage('You', message);

    fetch(apiEndpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      },
      body: JSON.stringify({ query: message })
    })
    .then(response => response.json())
    .then(data => {
      displayMessage('Bot', data.response);
    })
    .catch(error => {
      console.error('Error:', error);
    });
  }

  function displayMessage(sender, message) {
    const messageElement = document.createElement('div');
    messageElement.className = 'message';
    messageElement.innerHTML = `<strong>${sender}:</strong> ${message}`;
    chatBox.appendChild(messageElement);
    queryInput.value = '';
  }
});

